<?php
return array (
  'dscms' => 
  array (
    'jc' => 
    array (
      'logo1' => 'template/dianyingim/img/logo_1.png',
      'logo2' => 'template/dianyingim/img/logo_2.png',
      'icon' => 'template/dianyingim/img/icon.png',
      'pic' => 'template/dianyingim/img/loading.png',
      'gg' => 'Bạn đang xem phim tại ramcms',
      'txt' => '<p>Phim inguon</p>
<p>Admin ramcms: @brevis_ng</p>
<p>Nếu gặp bất cứ vấn đề gì, vui lòng phản hồi cho nhóm tác giả</p>
<p>Nhóm tele tác giả: <a href="https://t.me/+FPSDDbRPRuozNjZl" target="_blank"><strong>Bấm vào đây để nhanh chóng tham gia trò chuyện nhóm</strong></a>',
      'zhizhang' => 'Cảm ơn bạn đã xem phim tại ramcms, chia sẻ để mình có động lực up nhiều phim hay hơn ạ 😊',
      'sm' => 'Tất cả nội dung trên trang web này đến từ các tài nguyên được tham chiếu công khai do các trang web chia sẻ Internet cung cấp và không cung cấp dịch vụ tải lên và lưu trữ tài nguyên video.',
    ),
    'nav' => 
    array (
      'actor' => '1',
      'topic' => '1',
      'vip' => '1',
      'ivi' => '1',
      'zdyname1' => 'aaa1',
      'zdyurl1' => '111',
    ),
    'indexactor' => '1',
  ),
);