<?php
return array (
  'dscms' => 
  array (
    'slide' => '1',
    'slidecline' => 
    array (
      0 => 'topshow',
      1 => 'lrshow',
    ),
    'module' => 
    array (
      0 => 'index_level',
      1 => 'index_hto',
      2 => 'index_art',
      4 => 'index_zhibo',
      5 => 'index_actor',
      6 => 'index_topic',
      7 => 'index_hezuo',
    ),
    'zhiboul' => 'http://127.0.0.1/index.php/vod/type/id/zhibo.html',
    'taobaoul' => 'http://demo.dataoke.com/',
    'logtype' => '1,2,3,4',
    'hnum' => '16',
    'indexactor' => '1',
    'gx' => 
    array (
      'debugging' => '1',
      'zt' => '0',
      'btn' => '0',
      'donghua' => '1',
      'listtag' => '1',
      'lazy1' => '/template/ec_TV/images/load.gif',
      'lazy2' => '/template/ec_TV/images/ipcbg.gif',
      'lazy3' => '/template/ec_TV/images/adminavr.jpeg',
      'soconet' => '短视cms多功能主题',
    ),
    'nav' => 
    array (
      'actor' => '1',
      'topic' => '1',
      'vip' => '1',
      'ivi' => '1',
      'zdyname1' => 'aaa1',
      'zdyurl1' => '111',
      'zdyname2' => 'aaa2',
      'zdyurl2' => '222',
    ),
    'viptc' => '1',
    'aa01' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_TV/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa02' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_TV/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa03' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_TV/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa04' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_TV/images/vip1.png" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa05' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_TV/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'indextccont' => '1.如播卡顿或失败可切换片源。<br/>2.建议选择腾讯视频,爱奇艺,优酷等片源播放，速度更快画质更好，如播放失败可点击切换线路。<br/>3.请不要相信视频中的广告,视频中广告非本站所加。<br/>4.如需下载缓存视频使用QQ手机浏览器访问播放页即可看到下载按钮。',
    'public' => '0',
    'seo' => 
    array (
      'votitle' => '高清在线播放',
      'actitle' => '全部电影作品',
    ),
    'pd' => 
    array (
      'detailart' => '1',
      'jxxlof' => '1',
      'jxxl' => 'http://jx.drgxj.com/?url=,https://jiexi.380k.com/?url=,https://vip.66parse.club/?url=,http://jx.drgxj.com/?url=',
      'gzh' => '/template/ec_TV/images/ewm.png',
      'zhifubao' => '/template/ec_TV/images/null.jpg',
      'weixin' => '/template/ec_TV/images/null.jpg',
      'anma' => '/template/ec_TV/images/ewm.png',
      'pingma' => '/template/ec_TV/images/ewm.png',
      'anul' => '',
      'pingul' => '',
      'qqul' => '',
      'vodpl' => '1',
      'ratpl' => '1',
      'commentof' => '1',
    ),
  ),
);