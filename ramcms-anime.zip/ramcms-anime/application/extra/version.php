<?php
return array (
    'name' => 'RamCMS',
    'copyright' => 'RamCMS',
    'url' => '//github.com/brevis-ng/ramcms',
    'code' => '2023.1000.3052.2',
    'license' => 'MIT',
);
?>