<?php
return array (
  'nguon' => 
  array (
    'status' => '1',
    'from' => 'nguon',
    'show' => 'Vietsub #2',
    'des' => 'Nguon embed',
    'target' => '_self',
    'ps' => '0',
    'parse' => '',
    'sort' => '909',
    'tip' => 'Trình phát embed có hỗ trợ TVC',
    'id' => 'nguon',
  ),
  'ngm3u8' => 
  array (
    'status' => '1',
    'from' => 'ngm3u8',
    'show' => 'Vietsub #1',
    'des' => 'Nguon M3U8',
    'target' => '_self',
    'ps' => '0',
    'parse' => '',
    'sort' => '908',
    'tip' => 'Trình phát HSL có hỗ trợ TVC',
    'id' => 'ngm3u8',
  ),
);